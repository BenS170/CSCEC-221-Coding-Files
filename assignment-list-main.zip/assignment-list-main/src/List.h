#pragma once

#include <cstddef> // size_t
#include <iterator> // std::bidirectional_iterator_tag
#include <type_traits> // std::is_same, std::enable_if
#include <iostream>

template <class T>
class List {
    private:
    struct Node {
        Node *next, *prev;
        T data;
        explicit Node(Node* prev = nullptr, Node* next = nullptr)
        : next{next}, prev{prev} {}
        explicit Node(const T& data, Node* prev = nullptr, Node* next = nullptr)
        : next{next}, prev{prev}, data{data} {}
        explicit Node(T&& data, Node* prev = nullptr, Node* next = nullptr)
        : next{next}, prev{prev}, data{std::move(data)} {}
    };

    template <typename pointer_type, typename reference_type>
    class basic_iterator {
    public:
        using iterator_category = std::bidirectional_iterator_tag;
        using value_type        = T;
        using difference_type   = ptrdiff_t;
        using pointer           = pointer_type;
        using reference         = reference_type;
    private:
        friend class List<value_type>;
        using Node = typename List<value_type>::Node;

        Node* node;

        explicit basic_iterator(Node* ptr) noexcept : node{ptr} {}
        explicit basic_iterator(const Node* ptr) noexcept : node{const_cast<Node*>(ptr)} {}

    public:
        basic_iterator() { node = nullptr; };
        basic_iterator(const basic_iterator&) = default;
        basic_iterator(basic_iterator&&) = default;
        ~basic_iterator() = default;
        basic_iterator& operator=(const basic_iterator&) = default;
        basic_iterator& operator=(basic_iterator&&) = default;

        reference operator*() const {
            // TODO
            return node->data;
            
        }
        pointer operator->() const {
            // TODO
            T* data = &node->data;
            return data;
        }

        // Prefix Increment: ++a
        basic_iterator& operator++() {
            // TODO
            node = node->next;
            return *this;
        }
        // Postfix Increment: a++
        basic_iterator operator++(int) {
            // TODO
            basic_iterator iter(node);
            node = node->next;
            return iter;

        }
        // Prefix Decrement: --a
        basic_iterator& operator--() {
            // TODO
            node = node->prev;
            return *this;
        }
        // Postfix Decrement: a--
        basic_iterator operator--(int) {
            // TODO
            basic_iterator iter(node);
            node = node->prev;
            return iter;
        }

        bool operator==(const basic_iterator& other) const noexcept {
            // TODO
            return node == other.node;
        }
        bool operator!=(const basic_iterator& other) const noexcept {
            // TODO
            return !(node==other.node);
        }
    };

public:
    using value_type      = T;
    using size_type       = size_t;
    using difference_type = ptrdiff_t;
    using reference       = value_type&;
    using const_reference = const value_type&;
    using pointer         = value_type*;
    using const_pointer   = const value_type*;
    using iterator        = basic_iterator<pointer, reference>;
    using const_iterator  = basic_iterator<const_pointer, const_reference>;

private:
    Node head, tail;
    size_type _size;

public:
    List() {
        // TODO - Don't forget the list initializer
        _size = 0;

        head.next = &tail;
        tail.prev = &head;
        head.prev = nullptr;
        tail.next = nullptr;

    }
    List( size_type count, const T& value ) {
        // TODO - Don't forget the list initializer
        _size = count;
        head.next = &tail;
        tail.prev = &head;
        head.prev = nullptr;
        tail.next = nullptr;

        for (int i = 0; i<count; i++){
            Node* a = new Node(value, &head, head.next);
            head.next = a;
            a->next->prev = a;
        }
    }
    explicit List( size_type count ) {
        // TODO - Don't forget the list initializer
        _size = count;
        head.next = &tail;
        tail.prev = &head;
        head.prev = nullptr;
        tail.next = nullptr;

        for (int i = 0; i<count; i++){
            Node* a = new Node(T(), &head, head.next);
            head.next = a;
            a->next->prev = a;
        }

    }
    List( const List& other ) {
        // TODO - Don't forget the list initializer
        _size = other.size();
        head.next = &tail;
        tail.prev = &head;
        head.prev = nullptr;
        tail.next = nullptr;

        Node* curr_copy = other.head.next;

        for (int i = 0; i<_size; i++){
            Node* a = new Node(curr_copy->data, tail.prev, &tail);
            tail.prev = a;
            a->prev->next = a;

            curr_copy = curr_copy->next;

        }
    }
    List( List&& other ) {
        // TODO - Don't forget the list initializer
        _size = std::move(other._size);
        head.next = &tail;
        tail.prev = &head;
        head.prev = nullptr;
        tail.next = nullptr;

        head.next = other.head.next;
        other.head.next->prev = &head;
        tail.prev = other.tail.prev;
        other.tail.prev->next = &tail;
        
        other.head.next = &other.tail;
        other.tail.prev = &other.head;
        other._size = 0;


    }
    ~List() {
        // TODO
        Node* curr_node = head.next;
        while(curr_node != &tail){
            Node* next = curr_node->next;
            delete curr_node;
            curr_node = next;
        }
    }
    List& operator=( const List& other ) {
        // TODO
        if (&other == this){
            return *this;
        }

        this->clear();
        _size = other.size();
        head.next = &tail;
        tail.prev = &head;
        head.prev = nullptr;
        tail.next = nullptr;

        Node* curr_copy = other.head.next;

        for (int i = 0; i<_size; i++){
            Node* a = new Node(curr_copy->data, tail.prev, &tail);
            tail.prev = a;
            a->prev->next = a;

            curr_copy = curr_copy->next;

        }

        return *this;
    }
    List& operator=( List&& other ) noexcept {
        // TODO
        if (&other == this){
            return *this;
        }

        this->clear();

        _size = std::move(other._size);
        head.next = &tail;
        tail.prev = &head;
        head.prev = nullptr;
        tail.next = nullptr;

        head.next = other.head.next;
        other.head.next->prev = &head;
        tail.prev = other.tail.prev;
        other.tail.prev->next = &tail;
        
        other.head.next = &other.tail;
        other.tail.prev = &other.head;
        other._size = 0;


    }

    reference front() {
        // TODO
        reference a = head.next->data;
        return a;
    }
    const_reference front() const {
        // TODO
        const_reference a = head.next->data;
        return a;
    }
	
    reference back() {
        // TODO
        reference a = tail.prev->data;
        return a;
    }
    const_reference back() const {
        // TODO
        const_reference a = tail.prev->data;
        return a;
    }
	
    iterator begin() noexcept {
        // TODO
        iterator iter(head.next);
        
        return iter;
    }
    const_iterator begin() const noexcept {
        // TODO
        const_iterator iter(head.next);
        
        return iter;
    }
    const_iterator cbegin() const noexcept {
        // TODO
        const_iterator iter(head.next);
        
        return iter;
    }

    iterator end() noexcept {
        // TODO
        iterator iter(&tail);
        
        return iter;
    }
    const_iterator end() const noexcept {
        // TODO
        const_iterator iter(&tail);
        
        return iter;
    }
    const_iterator cend() const noexcept {
        // TODO
        const_iterator iter(&tail);
        
        return iter;
    }

    bool empty() const noexcept {
        // TODO
        if (head.next == &tail && tail.prev == &head && _size==0){
            return true;
        }
        return false;
    }

    size_type size() const noexcept {
        // TODO
        return _size;
    }

    void clear() noexcept {
        // TODO
        Node* curr_node = head.next;
        while(curr_node != &tail){
            Node* next = curr_node->next;
            delete curr_node;
            curr_node = next;
        }
        head.next = &tail;
        tail.prev = &head;
        head.prev = nullptr;
        tail.next = nullptr;
        _size = 0;
    }

    iterator insert( const_iterator pos, const T& value ) {
        // TODO
        _size++;

        Node* a = new Node(value, pos.node->prev, pos.node);
        pos.node->prev = a;
        a->prev->next = a;

        return iterator(a);
    }
    iterator insert( const_iterator pos, T&& value ) {
        // TODO
        
        _size++;
        Node* a = new Node();
        a->data = std::move(value);
        a->prev = pos.node->prev;
        a->next = pos.node;
        pos.node->prev = a;
        a->prev->next = a;

        return iterator(a);

    }

    iterator erase( const_iterator pos ) {
        // TODO
        
        _size--;
        iterator a(pos.node->next);

        pos.node->prev->next = pos.node->next;
        pos.node->next->prev = pos.node->prev;
        
        delete pos.node;

        return a;
    }

    void push_back( const T& value ) {
        // TODO
        _size++;

        Node* a = new Node(value, tail.prev, &tail);
        tail.prev = a;
        a->prev->next = a;

        
    }
    void push_back( T&& value ) {
        // TODO
        _size++;
        Node* a = new Node();
        a->data = std::move(value);
        a->prev = tail.prev;
        a->next = &tail;
        tail.prev = a;
        a->prev->next = a;
    }

    void pop_back() {
        // TODO
        _size--;
        iterator a(tail.prev);

        tail.prev->prev->next = &tail;
        tail.prev = tail.prev->prev;

        delete a.node;

    }
	
    void push_front( const T& value ) {
        // TODO
        _size++;

        Node* a = new Node(value, &head, head.next);
        head.next = a;
        a->next->prev = a;

    }
	void push_front( T&& value ) {
        // TODO
        _size++;
        Node* a = new Node();
        a->data = std::move(value);
        a->prev = &head;
        a->next = head.next;
        head.next = a;
        a->next->prev = a;
    }

    void pop_front() {
        // TODO
        _size--;
        iterator a(head.next);

        head.next->next->prev = &head;
        head.next = head.next->next;

        delete a.node;
    }

    /*
      You do not need to modify these methods!
      
      These method provide the non-const complement 
      for the const_iterator methods provided above.
    */
    iterator insert( iterator pos, const T & value) { 
        return insert((const_iterator &) (pos), value);
    }

    iterator insert( iterator pos, T && value ) {
        return insert((const_iterator &) (pos), std::move(value));
    }

    iterator erase( iterator pos ) {
        return erase((const_iterator&)(pos));
    }
};


/*
    You do not need to modify these methods!

    These method provide a overload to compare const and 
    non-const iterators safely.
*/
 
namespace {
    template<typename Iter, typename ConstIter, typename T>
    using enable_for_list_iters = typename std::enable_if<
        std::is_same<
            typename List<typename std::iterator_traits<Iter>::value_type>::iterator, 
            Iter
        >{} && std::is_same<
            typename List<typename std::iterator_traits<Iter>::value_type>::const_iterator,
            ConstIter
        >{}, T>::type;
}

template<typename Iterator, typename ConstIter>
enable_for_list_iters<Iterator, ConstIter, bool> operator==(const Iterator & lhs, const ConstIter & rhs) {
    return (const ConstIter &)(lhs) == rhs;
}

template<typename Iterator, typename ConstIter>
enable_for_list_iters<Iterator, ConstIter, bool> operator==(const ConstIter & lhs, const Iterator & rhs) {
    return (const ConstIter &)(rhs) == lhs;
}

template<typename Iterator, typename ConstIter>
enable_for_list_iters<Iterator, ConstIter, bool> operator!=(const Iterator & lhs, const ConstIter & rhs) {
    return (const ConstIter &)(lhs) != rhs;
}

template<typename Iterator, typename ConstIter>
enable_for_list_iters<Iterator, ConstIter, bool> operator!=(const ConstIter & lhs, const Iterator & rhs) {
    return (const ConstIter &)(rhs) != lhs;
}
