#include <string>
#include <sstream>

#include "Card.h"

int rand221(void) {
    return rand();
}

// You may want to write the following three functions, but they are not required

std::ostream& operator<<(std::ostream& out, const Suit& suit) {
    if (suit == Suit::SPADES){
        out << "Spades";
    }
    if (suit == Suit::CLUBS){
        out << "Clubs";
    }
    if (suit == Suit::DIAMONDS){
        out << "Diamonds";
    }
    if (suit == Suit::HEARTS){
        out << "Hearts";
    }
    return out;

}


Rank to_rank(const std::string& string) {

    if (string == "ace"){
        return ACE;
    }

    if (string == "2"){
        return 2;
    }
    if (string == "3"){
        return 3;
    }
    if (string == "4"){
        return 4;
    }
    if (string == "5"){
        return 5;
    }
    if (string == "6"){
        return 6;
    }
    if (string == "7"){
        return 7;
    }
    if (string == "8"){
        return 8;
    }
    if (string == "9"){
        return 9;
    }
    if (string == "10"){
        return 10;
    }

    if (string == "jack"){
        return JACK;
    }
    if (string == "queen"){
        return QUEEN;
    }
    if (string == "king"){
        return KING;
    }

    return 0;

}

Suit to_suit(std::string suit){
    
    if (suit == "spades"){
        return Suit::SPADES;
    }
    if (suit == "diamonds"){
        return Suit::DIAMONDS;
    }
    if (suit == "clubs"){
        return Suit::CLUBS;
    }
    if (suit == "hearts"){
        return Suit::HEARTS;
    }

}

std::istream& operator>>(std::istream& in, Card& card) {
    std::string card_suit;
    std::getline(in, card_suit, ' ');
    card.suit = to_suit(card_suit);

    std::string card_rank;
    std::getline(in, card_rank, '\n');
    card.rank = to_rank(card_rank);

    return in;
}

List<Card> buildDeck(std::istream& file) {
    // TODO
    List<Card> list;
    std::stringstream ss;
    std::string curr_string = "";
    Card curr;
    while (getline(file, curr_string)){
        ss << curr_string;
        ss >> curr;
        
        ss.clear();
        ss.str("");

        list.push_back(curr);

    }
    return list;

}

List<Card> shuffle(const List<Card>& deck) {
    // TODO
    List<Card> new_deck;
    Card card;

    for (int i=0; i<deck.size(); i++){

        int r = rand221() % 2;

        auto iter = deck.cbegin();
        for (int j = 0; j<i; j++){
            iter++;
        }

        Card card = *iter;
        if(r==0){
            new_deck.push_front(card);
        } else{
            new_deck.push_back(card);
        }
        
    }

    return new_deck;

}