#include "executable.h"

TEST(gnp_dag) { ASSERT_SHORTEST_PATHS_MATCH("gnp_dag"); }