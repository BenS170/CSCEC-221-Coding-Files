#include "executable.h"

TEST(internet) { ASSERT_SHORTEST_PATHS_MATCH("internet"); }