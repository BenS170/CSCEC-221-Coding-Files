#include "executable.h"

TEST(complete_graph) { ASSERT_SHORTEST_PATHS_MATCH("complete_graph"); }