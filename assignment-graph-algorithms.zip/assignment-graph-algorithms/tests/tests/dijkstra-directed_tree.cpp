#include "executable.h"

TEST(directed_tree_branching) { ASSERT_SHORTEST_PATHS_MATCH("directed_tree"); }