#include "executable.h"

TEST(gnp_dag) { 
    ASSERT_TOPOLOGICAL_ORDERING("gnp_dag"); 
}