#include "executable.h"

TEST(complete_with_dropout) { ASSERT_SHORTEST_PATHS_MATCH("complete_with_dropout"); }