#include <cmath>
#include <fstream>
#include <sstream>

#include "Datum.h"

// You may want to write this function, but you do not have to
[[nodiscard]] bool isBadDataEntry(const Datum& datum);

std::ostream& operator<<(std::ostream& out, const Datum& datum){
    return out << datum.week << " " << datum.negative << " " << datum.positive << " " << datum.total << " " << datum.positivity << std::endl;
}

std::istream& operator>>(std::istream& in, Datum& datum){
    std::stringstream ss;
    
    std::string week;
    std::getline(in, week, ',');
    datum.week = week;

    std::string s_negative;
    std::getline(in, s_negative, ',');
    int negative = 0;
    ss << s_negative;
    ss >> negative;
    datum.negative = negative;

    ss.clear();
    ss.str("");

    std::string s_positive;
    std::getline(in, s_positive, ',');
    int positive = 0;
    ss << s_positive;
    ss >> positive;
    datum.positive = positive;

    ss.clear();
    ss.str("");

    std::string s_total;
    std::getline(in, s_total, ',');
    int total = 0;
    ss << s_total;
    ss >> total;
    datum.total = total;
    

    ss.clear();
    ss.str("");

    std::string s_positivity;
    std::getline(in, s_positivity, '%');
    float positivity = std::stof(s_positivity);
    datum.positivity = positivity;
    
    return in;
}

[[nodiscard]] Vector<Datum> readData(std::istream& file){
    Vector<Datum> vec;
    std::string string_data;
    std::getline(file, string_data);
    std::stringstream ss;
    Datum data;
    int i = 0;
    while (std::getline(file, string_data)){
        
        ss << string_data;
        ss >> data;
        
        ss.clear();
        ss.str("");
        vec.push_back(data);
        i++;
    }

    return vec;
}



[[nodiscard]] Vector<Datum> badDataEntries(const Vector<Datum>& data) noexcept{
    
    Vector<Datum> bad;
    if (data.size() == 0){
        return bad;
    }
    

    float pos;
    for (size_t i = 0; i<data.size(); i++){
        pos = data[i].positivity/100;
        if (data[i].compute_total() != data[i].total){
            bad.push_back(data[i]);
        } else if (data[i].compute_positivity() - pos > 0.001 || data[i].compute_positivity() - pos < -0.001){
            bad.push_back(data[i]);
        }
    }
    return bad;
}


[[nodiscard]] bool goodData(const Vector<Datum>& data) noexcept{
    Vector<Datum> vec = badDataEntries(data);
    if (vec.empty()){
        return true;
    }
    return false;
}