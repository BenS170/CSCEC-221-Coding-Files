#ifndef VECTOR_H
#define VECTOR_H

#include <algorithm> // std::random_access_iterator_tag
#include <cstddef> // size_t
#include <stdexcept> // std::range_error
#include <iostream>

template <class T>
class Vector {
public:
    class iterator;
private:
    T* array;
    size_t _capacity, _size;

    // You may want to write a function that grows the vector
    void grow(){
        if (_capacity == 0) {
            _capacity = 1;
            array = new T[_capacity];
            return;
        } else {
            _capacity *= 2;
        }
        T* new_array = new T[_capacity];
        for (size_t i = 0; i < _size-1; i++) {
            
            new_array[i] = std::move(array[i]);
        }
        delete[] array;
        
        array = new_array;
    }

public:
    Vector() noexcept{
        array = nullptr;
        _size = 0;
        _capacity = 0;
    }
    Vector(size_t count, const T& value){
        _size = count;
        _capacity = count;
        array = new T[count];

        for (int i = 0; i<count; i++){
            array[i] = value;
        }

    }
    explicit Vector(size_t count){
        _size = count;
        _capacity = count;
        array = new T[count];
        T zero = T();
        for (size_t i = 0; i<count; i++){
            array[i] = zero;
        }
    }
    Vector(const Vector& other){
        _size = other._size;
        _capacity = other._capacity;
        array = new T[_capacity];

        for (int i = 0; i<_size; i++){
            array[i] = other.array[i];
        }
    }
    Vector(Vector&& other) noexcept{
        
        _size = other._size;
        _capacity = other._capacity;

        other._capacity = 0;
        other._size = 0;

        this->array = other.array;
        other.array = nullptr;
    }

    ~Vector(){
        delete[] array;
    }

    Vector& operator=(const Vector& other){

        if (this == &other){
            return *this;
        }

        delete[] array;
        _size = other._size;
        _capacity = other._capacity;
        array = new T[_capacity];

        for (int i = 0; i<_size; i++){
            array[i] = other.array[i];
        }
        
        return *this;
    }
    Vector& operator=(Vector&& other) noexcept{
        if (this == &other){
            return *this;
        }
        
        _size = other._size;
        _capacity = other._capacity;

        other._size = 0;
        other._capacity = 0;

    
        if (other.array == nullptr){
            array = nullptr;
            return *this;
        }
        
        delete[] array;

        this->array = other.array;
        other.array = nullptr;
    
        

        return *this;
    }

    iterator begin() noexcept{
        iterator beg(array[0]);
        return beg;
    }
    iterator end() noexcept{
        iterator end(array[_size]);
        return end;
    }

    [[nodiscard]] bool empty() const noexcept{
        if (_size == 0){
            return true;
        }
        return false;
    }

    size_t size() const noexcept{
        return _size;
    }
    size_t capacity() const noexcept{
        return _capacity;
    }

    T& at(size_t pos){
        if (pos >= _size || pos<0){
            throw std::out_of_range("bleh");
        }
        return array[pos];
    }
    const T& at(size_t pos) const{
        if (pos>= _size || pos<0){
            throw std::out_of_range("bleh");
        }
        return array[pos];
    }

    T& operator[](size_t pos){
        return array[pos];
    }
    const T& operator[](size_t pos) const{
        return array[pos];
    }


    T& front(){
        return array[0];
    }
    const T& front() const{
        return array[0];
    }
    T& back(){
        return array[_size-1];
    }
    const T& back() const{
        return array[_size-1];
    }

    void push_back(const T& value){
        
        _size++;
        if (_size > _capacity || _capacity == 0){
            grow();
        }
        
        
        array[_size-1] = value;
        
    }
    void push_back(T&& value){
        
        _size++;
        
        if (_size > _capacity || _capacity == 0){
            grow();
        }
        
        array[_size-1] = std::move(value);
        
        
    }
    void pop_back(){
        if (_size == 0){
            throw std::out_of_range("bleh");
        }
        _size--;
    }

    iterator insert(iterator pos, const T& value){
        
        
        iterator temp;
        temp = begin();
        int i = 0;
        while(pos != temp){
            temp++;
            i++;
        }

        _size++;
        
        if (_size > _capacity){
            _capacity *=2;
        }
        
        T* new_array = new T[_capacity];
        for (int j = 0; j<_size; j++){
            if (j==i){
                new_array[j] = value;
            } else if (j>i){
                new_array[j] = std::move(array[j-1]);
            }else{
                new_array[j] = std::move(array[j]);
            }
        }
        
        delete[] array;
        array = new_array;
        temp = begin();
        temp += i;
        return temp;
    }
    iterator insert(iterator pos, T&& value){
        iterator temp;
        temp = begin();
        int i = 0;
        while(pos != temp){
            temp++;
            i++;
        }

        _size++;
        
        if (_size > _capacity){
            _capacity *=2;
        }
        
        T* new_array = new T[_capacity];
        for (int j = 0; j<_size; j++){
            if (j==i){
                new_array[j] = std::move(value);
            } else if (j>i){
                new_array[j] = std::move(array[j-1]);
            }else{
                new_array[j] = std::move(array[j]);
            }
        }
        
        delete[] array;
        array = new_array;
        temp = begin();
        temp += i;
        return temp;
    }
    iterator insert(iterator pos, size_t count, const T& value){

        
        iterator temp;
        temp = begin();
        size_t i = 0;
        while(pos != temp){
            temp++;
            i++;
        }


        size_t orig_size = _size;
        _size += count;
        

        while (_size>_capacity){
            if (_capacity *2 >= _size){
                break;
            }
            _capacity *= 2;
            T* new_array = new T[_capacity];
            for (size_t i = 0; i < orig_size; i++) {
                
                new_array[i] = std::move(array[i]);
            }
            delete[] array;
        
            array = new_array;
            
        }
        
        _capacity *= 2;


        size_t last = i+count;
        T* new_array = new T[_capacity];
        

        for (size_t j = 0; j<_size; j++){
            if (j>=i && j<last){
                
                new_array[j] = value;
            } else if (j>=last){
                new_array[j] = std::move(array[j-count]);
            }else{
                new_array[j] = std::move(array[j]);
            }
        }
        
        delete[] array;
        array = new_array;
        temp = begin();
        temp += i;
        return temp;
    }
    iterator erase(iterator pos){

        if(_size == 0){
            return pos;
        }

        iterator temp;
        temp = begin();
        int i = 0;
        while(pos != temp){
            temp++;
            i++;
        }

        for (i; i<_size-1; i++){
            array[i] = array[i+1];
        }
        _size--;
        return pos++;

    }
    iterator erase(iterator first, iterator last){
        if(_size == 0){
            return last;
        }

        iterator temp;
        temp = begin();
        int start = 0;
        while(first != temp){
            temp++;
            start++;
        }

        int how_many = 0;
        while(last != temp){
            how_many++;
            temp++;
        }

        for (start; start<_size-how_many; start++){
            array[start] = array[start+how_many];
        }

        _size -= how_many;
        
        return first;
    }

    class iterator {
    public:
        using iterator_category = std::random_access_iterator_tag;
        using value_type        = T;
        using difference_type   = ptrdiff_t;
        using pointer           = T*;
        using reference         = T&;

        
    private:
        // Add your own data members here
        // HINT: For random_access_iterator, the data member is a pointer 99.9% of the time
        
        T* ptr;
    public:
        iterator() : ptr(nullptr) {}
        iterator(const iterator& other) : ptr(other.ptr){}
        iterator(T& other) : ptr(&other){}
        
        //copy constructor

        // Add any constructors that you may need

        // This assignment operator is done for you, please do not add more
        iterator& operator=(const iterator&) noexcept = default;

        [[nodiscard]] reference operator*() const noexcept{
            return *ptr;
        }
        [[nodiscard]] pointer operator->() const noexcept{
            return ptr;
        }

        // Prefix Increment: ++a
        iterator& operator++() noexcept{
            
            ++(this->ptr);
            return *this;
        }
        // Postfix Increment: a++
        iterator operator++(int) noexcept{
            iterator temp = *this;
            ++(this->ptr);
            return temp;
        }

        // Prefix Decrement: --a
        iterator& operator--() noexcept{
            --(this->ptr);
            return *this;
        }
        // Postfix Decrement: a--
        iterator operator--(int) noexcept{
            iterator temp = *this;
            --(this->ptr);
            return temp;
        }

        iterator& operator+=(difference_type offset) noexcept{
            ptr += offset;
            return *this;
        }
        [[nodiscard]] iterator operator+(difference_type offset) const noexcept{
            iterator temp = *this;
            temp.ptr += offset;
            return temp;
        }
        
        iterator& operator-=(difference_type offset) noexcept{
            ptr -= offset;
            return *this;
        }
        [[nodiscard]] iterator operator-(difference_type offset) const noexcept{
            iterator temp = *this;
            temp.ptr -= offset;
            return temp;
        }

        [[nodiscard]] difference_type operator-(const iterator& rhs) const noexcept{
            difference_type ans;
            iterator temp = *this;
            ans = temp.ptr-rhs.ptr;
            return ans;
        }

        [[nodiscard]] reference operator[](difference_type offset) const noexcept{
            iterator temp = *this;
            temp = temp + offset;
            return (*temp.ptr);
        }


        //COMPARISON
        [[nodiscard]] bool operator==(const iterator& rhs) const noexcept{
            if (this->ptr == rhs.ptr){
                return true;
            }
            return false;
        }
        [[nodiscard]] bool operator!=(const iterator& rhs) const noexcept{
            if (this->ptr != rhs.ptr){
                return true;
            }
            return false;
        }
        [[nodiscard]] bool operator<(const iterator& rhs) const noexcept{
            if (this->ptr < rhs.ptr){
                return true;
            }
            return false;
        }
        [[nodiscard]] bool operator>(const iterator& rhs) const noexcept{
            if (this->ptr > rhs.ptr){
                return true;
            }
            return false;
        }
        [[nodiscard]] bool operator<=(const iterator& rhs) const noexcept{
            if (this->ptr <= rhs.ptr){
                return true;
            }
            return false;
        }
        [[nodiscard]] bool operator>=(const iterator& rhs) const noexcept{
            if (this->ptr >= rhs.ptr){
                return true;
            }
            return false;
        }
    };


    void clear() noexcept{
        for (int i = 0; i<_size; i++){
            array[i] = NULL;
        }

        _size = 0;
    }
};

template <class T>
[[nodiscard]] typename Vector<T>::iterator operator+(typename Vector<T>::iterator::difference_type offset, typename Vector<T>::iterator iterator) noexcept;


#endif
